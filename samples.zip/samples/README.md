# VectorForge sample test pack

Upload one file at a time from this folder after starting the Docker stack. For every successful conversion, confirm that the **Vector result** pane and the downloaded SVG show the same artwork. A successful SVG should contain editable `<path>` elements; it must not be an empty SVG wrapper.

| File | Test case | Expected result |
| --- | --- | --- |
| `line-art-signature.png` | Sparse single-ink signature | Auto-selects **Line art**. Result is a small number of dark filled paths. |
| `flat-logo.png` | Flat multi-colour logo | Auto-selects **Illustration**. Result contains multiple coloured paths. |
| `transparent-icon.png` | Transparent-background icon | Auto-selects Illustration. Foreground metadata should report `alpha`; transparent background stays transparent. |
| `noisy-sketch.png` | Sketch on a noisy background | Start with **Line art** and test segmentation both off and on. Tiny grey dots should be removed as the minimum detail area increases. |
| `multicolor-fruits.jpg` | Rich multi-colour raster | Illustration is an acceptable starting point. It is deliberately not a quality-golden test because it is photographic. |
| `photo-lena.jpg` | Photograph outside the intended scope | Expect a photo-like warning or an imperfect Illustration fallback. Do not judge it as a supported artwork conversion. |
| `document-sudoku.png` | Document/table-like input outside scope | Must not be treated as a quality vector-art result. Depending on eligible contours it may fail with the no-shape message or produce an unsuitable result; it must never claim a blank SVG is complete. |
| `blank-white.png` | No foreground artwork | Must fail with the no-editable-shapes message. There must be no SVG download. |
| `corrupt-image.jpg` | Invalid image content | Must be rejected by upload/content validation. |
| `oversized-upload.png` | 11 MB size limit | Must be rejected before image decoding with the 10 MB limit message. |

## Recommended manual regression flow

1. Upload `flat-logo.png`, wait for **Illustration**, vectorize, and download the SVG.
2. Change to **Line art**. The prior preview and downloads must clear immediately.
3. Vectorize again. The new SVG must differ from the Illustration SVG.
4. Upload `blank-white.png`. Confirm a failure rather than a blank SVG download.
5. Upload `transparent-icon.png` and confirm the foreground source reports `alpha`.
6. Upload `corrupt-image.jpg` and `oversized-upload.png` to verify client-side validation.
7. Use `photo-lena.jpg` and `document-sudoku.png` only to verify clear limitations/failure handling—not output fidelity.

## Provenance

- `photo-lena.jpg`, `document-sudoku.png`, and `multicolor-fruits.jpg` are retrieved from the [OpenCV sample-data repository](https://github.com/opencv/opencv/tree/4.x/samples/data) on 2026-07-18. OpenCV is Apache-2.0 licensed.
- The remaining artwork samples are project-created SVGs and their generated PNG derivatives. They contain no user uploads or model weights.
